# Caleb Crypto Mining — Vercel starter

A responsive static website prototype for Caleb Crypto Mining.

## Deploy to Vercel
1. Import this folder/repository into Vercel.
2. Framework preset: **Other**.
3. Build command: `npm run build` (or leave blank).
4. Output directory: `.`.
5. Deploy.

## Important limitations
This is a **front-end prototype**, not a real mining or payment service. It does not mine cryptocurrency, create real earnings, authenticate users securely, store server-side accounts, or send blockchain payouts. Browser localStorage is used only for preview interactions. Do not use it to collect sensitive or financial information.

Before production, add a secure backend/database, authentication, admin access controls, verified mining/reward source, transaction reconciliation, payout provider or audited manual payout workflow, abuse prevention, and privacy/consent disclosures. Never request seed phrases or private keys. Do not sell or share personal data without informed consent and legal compliance.

Contact: taribeat@gmail.com
